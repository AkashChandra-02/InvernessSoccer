<!DOCTYPE html>
<html>
<head>

<link rel="SHORTCUT ICON" href="favicon.ico" type="image/x-icon" />
<link rel="ICON" href="favicon.ico" type="image/ico" />

<title>Inverness Soccer Club</title>

<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/sticky-footer-navbar.css">
</head>

<body>
<header>
<!-- navbar -->
      <nav style="background-color: #f5f5f5;" class="navbar navbar-expand-md fixed-top">
        
		<!--image that links back home-->
		<a class="navbar-brand" href="index.php"><img alt="Inverness Soccer Logo" src="/img/logo.png"
         width=58" height="60"></a>
			
		<a href="index.php">Home</a>	
		<a href="registration.php">Registration</a>
		<a href=".php">Calender</a>
		<a href="sponsors.php">Sponsors</a>
		<a href="FAQ.php">FAQ</a>
		<a href=".php">Equipment</a>
		<a href=".php">Soccer Camp</a>	
		
      </nav>
    </header>
<!--Body-->
<div role="main" class="container">
		<h1>Welcome to Inverness Soccer Club</h1>
	
<?php
$myfile = fopen("txt/registration.txt", "r") or die("Unable to open file!");

while(!feof($myfile)) {
	$line =  fgets($myfile);
	if(stripos($line,".com") != 0 || stripos($line,".org") != 0 || stripos($line,".net") != 0 || stripos($line,".php") != 0)
	{
		$out = '<a href='. $line.'>Link For Registration</a>';
		echo $out;
	}
	else
	{
		echo $line.'<br><br>';
	}
}
fclose($myfile);
?>

</div>
</body>
<!-- footer -->
<footer class="footer">
	<a style = 'padding-left: 30px;' href="about.php">About</a>
    <a href="board.php">ISC Board</a>
	<a href=".php">ISC Mission Statement</a>
	<a href=".php">Coaches Page</a>
	<a href=".php">Volunteer Info</a>
	<a href=".php">Officials Page</a>
	<a href=".php">ISC Code of Conduct</a>
	<a href="https://www.cdc.gov/concussion/HeadsUp/Training/index.html">Concussion information</a>
</footer>


</html>